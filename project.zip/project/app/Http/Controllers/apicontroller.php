<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\EnpNeeds;

class apiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function index()
    {
        $EnpNeeds = EnpNeeds::all()->toArray();
        return $EnpNeeds;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function enpSave(Request $request)
    {
        $EnpNeeds = EnpNeeds::create($request->all());
        return $EnpNeeds;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            
            'Title'    =>  'required',
            'Description'     =>  'required',
            'Status' =>  'required'
        ]);
        $EnpNeeds = new EnpNeeds([
            
            'Title'    =>  $request->get('Title'),
            'Description'     =>  $request->get('Description'),
            'Status'     =>  $request->get('Status')
        ]);
        $EnpNeeds->save();
        return redirect()->route('EnpNeeds.create')->with('success', 'Data Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showbyID($id)
    {
        $EnpNeeds=EnpNeeds::find($id);
       return response()->json($EnpNeeds);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function ShowbyTitle($Title)
    {
        $EnpNeeds=EnpNeeds::find($Title);
       return response()->json($EnpNeeds);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function enpUpdateByID(Request $request,$id)
    {
      
        $EnpNeeds=EnpNeeds::find($id);
        $EnpNeeds->Title=$request->input('Title');
        $EnpNeeds->Description=$request->input('Description');
        $EnpNeeds->Status=$request->input('Status');
        $EnpNeeds->save();
        return response()->json($EnpNeeds);
        //$EnpNeeds->update($request->all());
       // return response()->json($EnpNeeds,200);
       // return EnpNeeds;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteByID(Request $request,$id)
    {
      $EnpNeeds=EnpNeeds::find($id);
      $EnpNeeds->delete();
      return response()->json($EnpNeeds);
    }
}
