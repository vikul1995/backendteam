<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnpNeeds extends Model
{
    protected $table="EnpNeeds";
    public $primaryKey='Title';
    public $timestamps=false;
    protected $fillable = ['Title', 'Description','Status'];
}
